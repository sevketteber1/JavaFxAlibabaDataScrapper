
package my.numberaddition;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import jdk.nashorn.internal.parser.TokenType;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class NewClass {
    public static ArrayList liste_yapici(String arama_kelimesi,int sayfasayisi,int paramiktari){
           
           String a="https://german.alibaba.com/products/teppich.html?IndexArea=product_en&page=1&viewtype=L&annual_revenue=AR1&param_order=RVN-3";
           String a1="https://german.alibaba.com/products/";
           String a2=arama_kelimesi;
           String a3=".html?IndexArea=product_en&page=";
           int a4=sayfasayisi;
           String a5="&viewtype=L&annual_revenue=AR";
           int a6=paramiktari;
           String a7="&param_order=RVN-3";
           
           ArrayList<String> liste=new ArrayList(); 
           
            
           for(int i=1;i<sayfasayisi+1;i++){
            liste.add(a1+a2+a3+a4+a5+a6+a7);
            }
           return liste;
       }
    public static void Islemci() throws FileNotFoundException, IOException {
        //EXCEL DOSYASININ ADININ BELİRLENMESİ VE OLUŞTURULMASI
        Scanner input_excel_adi=new Scanner(System.in);
        System.out.println("Oluşturulacak excel dosyasının adınnı girin!");
        String kelime=input_excel_adi.nextLine();
        
        Workbook wb=new HSSFWorkbook();
        FileOutputStream out=new FileOutputStream(new File("C://Users//alica//Documents//NetBeansProjects//WebScrape//"+kelime+".xls"));
        wb.write(out);
        out.close();
        Sheet sheet1=wb.createSheet("1.sayfa");
        
       
        //OLUŞTURUKMUŞ ARRAYLER
       ArrayList<String> firma_adi=new ArrayList<String>();
       ArrayList<String> firma_alibaba_adresi=new ArrayList<String>();
       ArrayList<String> firma_alibaba_contact=new ArrayList<String>();
       ArrayList<String> firma_websitesi=new ArrayList<String>();
       ArrayList<String> firma_yetkilisi=new ArrayList<String>();
       ArrayList<String> firma_ulke=new ArrayList<String>();
        
         //ARANACAK KELİMENİN GİRİLMESİ
        Scanner input_aranacak_kelime=new Scanner(System.in);
        System.out.println("Aranacak kelimeyi girin!");
        String aranacak_kelime=input_aranacak_kelime.nextLine();
        
        Scanner sayfa_sayisi=new Scanner(System.in);
        System.out.println("Kaç sayfa arama yapmak istiyorsunuz");
        int sayfa_sayi=sayfa_sayisi.nextInt();
        
        Scanner para_miktari=new Scanner(System.in);
        System.out.println("Firmanın bütçe büyüklüğünü seçin");
        System.out.println("0-1M$ arası için=1");
        System.out.println("1-2.5M$ arası için=2");
        System.out.println("2.5-5M$ arası için=3");
        System.out.println("5-10M$ arası için=4");
        System.out.println("10-50M$ arası için=5");
        System.out.println("50-100M$ arası için=6");
        System.out.println("100M$'dan fazlası için=7");
        int para=para_miktari.nextInt();
        
        //SAYFA GEÇİŞLERİ KONTROLLERİ
        int alibabaadresi_sayac=0;
        int alibabawebadresi_sayac=0;
        int firmayetkilikisi_sayac=0;
        int test_outout=0;
        
        ArrayList<String> liste=liste_yapici(aranacak_kelime, sayfa_sayi,para);
        //FOR DENEME  BAŞLANGIÇ
        for(int b=0;b<liste.size();b++){
            System.out.println(liste.get(b));
        }
        for(int r=0;r<liste.size();r++){
            
         String url=liste.get(r);
        Document document=Jsoup.connect(url).get();
        Elements links=document.select("div.stitle.util-ellipsis a[href]");
      
        
         //Firma adı ve Amazon linkini Arraylere yükleme
       for(Element link:links){
           firma_adi.add(link.text());
           firma_alibaba_adresi.add("https:"+link.attr("href"));

         }
            System.out.println("ilk for sonrası firma size= "+firma_adi.size());
          
       //----------------------------------------------------------------------------------------------------
       //Firma alibaba contact adresinin Arraye yüklenmesi  //int alibabaadresi_sayac
       while(alibabaadresi_sayac<firma_alibaba_adresi.size()){
        firma_alibaba_contact.add(firma_alibaba_adresi.get(alibabaadresi_sayac)+"/contactinfo.html");
        alibabaadresi_sayac++;
       }
       System.out.println("ilk for sonrası firma alibaba contact size= "+firma_alibaba_contact.size());
         
         //----------------------------------------------------------------------------------------------------
         //Contact sayfasında Firmanın web adresine ulaşılması //int alibabawebadresi
       while(alibabawebadresi_sayac<firma_adi.size()){
           String contacturl=firma_alibaba_contact.get(alibabawebadresi_sayac);
         Document doc12=Jsoup.connect(contacturl)
               .userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0")
               .referrer("http://www.google.com") 
               .timeout(1000*6) //it's in milliseconds, so this means 5 seconds.              
               .get();
         for(Element den:doc12.select("table.company a[href]")){
            firma_websitesi.add(den.attr("href"));
           
           break;
       } 
         alibabawebadresi_sayac++;
       }
           System.out.println("ilk for sonrası firma websitesi size= "+firma_websitesi.size());
         
         //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       while(firmayetkilikisi_sayac<firma_adi.size()){
           String contacturl=firma_alibaba_contact.get(firmayetkilikisi_sayac);
         Document doc123=Jsoup.connect(contacturl)
               .userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0")
               .referrer("http://www.google.com") 
               .timeout(1000*6) //it's in milliseconds, so this means 5 seconds.              
               .get();
         for(Element den1:doc123.select("table.info")){
           firma_yetkilisi.add(den1.select("tr:nth-of-type(1) > .name").text());
           firma_ulke.add(den1.select("tr:nth-of-type(5) > td.value:nth-of-type(2)").text());
           
            if(firma_ulke.get(firmayetkilikisi_sayac).equals("")){
               firma_ulke.set(firmayetkilikisi_sayac, den1.select("tr:nth-of-type(4) > td.value:nth-of-type(2)").text());
               if(firma_ulke.get(firmayetkilikisi_sayac).equals("")){
                    firma_ulke.set(firmayetkilikisi_sayac, den1.select("tr:nth-of-type(3) > td.value:nth-of-type(2)").text());
               
               if(firma_ulke.get(firmayetkilikisi_sayac).equals("")){
                    firma_ulke.set(firmayetkilikisi_sayac, den1.select("tr:nth-of-type(2) > .value").text());
             
           }}}

           Row row=sheet1.createRow(firmayetkilikisi_sayac);
           Row row2=sheet1.createRow(firmayetkilikisi_sayac);
           Row row3=sheet1.createRow(firmayetkilikisi_sayac);
           Row row4=sheet1.createRow(firmayetkilikisi_sayac);
           Row row5=sheet1.createRow(firmayetkilikisi_sayac);
           
           Cell cell =row.createCell(0);
           Cell cell2 =row2.createCell(1);
           Cell cell3 =row3.createCell(2);
           Cell cell4 =row4.createCell(3);
           Cell cell5 =row5.createCell(4);
           
           cell.setCellValue(firma_adi.get(firmayetkilikisi_sayac));
           cell2.setCellValue(firma_alibaba_adresi.get(firmayetkilikisi_sayac));
           cell3.setCellValue(firma_websitesi.get(firmayetkilikisi_sayac));
           cell4.setCellValue(firma_yetkilisi.get(firmayetkilikisi_sayac));
           cell5.setCellValue(firma_ulke.get(firmayetkilikisi_sayac));
           break;
       }
         firmayetkilikisi_sayac++;
       }
           System.out.println("ilk for sonrası firma alibaba yetkili size= "+firma_yetkilisi.size());
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         //----------------------------------------------------------------------------------------------------
         //KONTROL

         
          while(test_outout<firma_adi.size()){
              System.out.println(firma_adi.get(test_outout));
             System.out.println(firma_alibaba_adresi.get(test_outout));
             System.out.println(firma_websitesi.get(test_outout));
             System.out.println(firma_yetkilisi.get(test_outout));
             System.out.println(firma_ulke.get(test_outout));
             test_outout++;
          }
        
          FileOutputStream fileOut=new FileOutputStream("C://Users//alica//Documents//NetBeansProjects//WebScrape//"+kelime+".xls");
           wb.write(fileOut);
     
           
            System.out.println(r+". döngü tamamlandı");
            System.out.println(firma_adi.size()+"= döngü sonrası firma size'ı");
           
    }
    }
}
/*

  public static void main(String args[]) throws IOException {
        NewJFrame myObject=new NewJFrame();
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
         //EXCEL DOSYASININ ADININ BELİRLENMESİ VE OLUŞTURULMASI
        System.out.println("Oluşturulacak excel dosyasının adınnı girin!");
        String kelime=myObject.getTxtExcelpath().getSelectedText();
        
        Workbook wb=new HSSFWorkbook();
        FileOutputStream out=new FileOutputStream(new File("C://Users//alica//Documents//NetBeansProjects//WebScrape//"+kelime+".xls"));
        wb.write(out);
        out.close();
        Sheet sheet1=wb.createSheet("1.sayfa");
        
       
        //OLUŞTURUKMUŞ ARRAYLER
       ArrayList<String> firma_adi=new ArrayList<String>();
       ArrayList<String> firma_alibaba_adresi=new ArrayList<String>();
       ArrayList<String> firma_alibaba_contact=new ArrayList<String>();
       ArrayList<String> firma_websitesi=new ArrayList<String>();
       ArrayList<String> firma_yetkilisi=new ArrayList<String>();
       ArrayList<String> firma_ulke=new ArrayList<String>();
        
         //ARANACAK KELİMENİN GİRİLMESİ
       
        System.out.println("Aranacak kelimeyi girin!");
        String aranacak_kelime=myObject.getTxtProduct().getText();
        
        
        
        
        System.out.println("Kaç sayfa arama yapmak istiyorsunuz");
        String lol=myObject.getTxtPageNumber().getText();
        int sayfa_sayi=1;
        try{
        sayfa_sayi=Integer.parseInt(lol);
        }catch(NumberFormatException ex){ // handle your exception
   
}
       
        
        
        System.out.println("Firmanın bütçe büyüklüğünü seçin");
        System.out.println("0-1M$ arası için=1");
        System.out.println("1-2.5M$ arası için=2");
        System.out.println("2.5-5M$ arası için=3");
        System.out.println("5-10M$ arası için=4");
        System.out.println("10-50M$ arası için=5");
        System.out.println("50-100M$ arası için=6");
        System.out.println("100M$'dan fazlası için=7");
        String param=myObject.getTxtPara().getText();
        int para=0;
        try{
        para=Integer.parseInt(param);
        }catch(NumberFormatException ex){ // handle your exception
   
}
        
        //SAYFA GEÇİŞLERİ KONTROLLERİ
        int alibabaadresi_sayac=0;
        int alibabawebadresi_sayac=0;
        int firmayetkilikisi_sayac=0;
        int test_outout=0;
        
        ArrayList<String> liste=liste_yapici(aranacak_kelime, sayfa_sayi,para);
        //FOR DENEME  BAŞLANGIÇ
        for(int b=0;b<liste.size();b++){
            System.out.println(liste.get(b));
        }
       
        
        for(int r=0;r<liste.size();r++){
            
         String url=liste.get(r);
        Document document=Jsoup.connect(url).get();
        Elements links=document.select("div.stitle.util-ellipsis a[href]");
      
        
         //Firma adı ve Amazon linkini Arraylere yükleme
       for(Element link:links){
           firma_adi.add(link.text());
           firma_alibaba_adresi.add("https:"+link.attr("href"));

         }
            System.out.println("ilk for sonrası firma size= "+firma_adi.size());
          
       //----------------------------------------------------------------------------------------------------
       //Firma alibaba contact adresinin Arraye yüklenmesi  //int alibabaadresi_sayac
       while(alibabaadresi_sayac<firma_alibaba_adresi.size()){
        firma_alibaba_contact.add(firma_alibaba_adresi.get(alibabaadresi_sayac)+"/contactinfo.html");
        alibabaadresi_sayac++;
       }
       System.out.println("ilk for sonrası firma alibaba contact size= "+firma_alibaba_contact.size());
         
         //----------------------------------------------------------------------------------------------------
         //Contact sayfasında Firmanın web adresine ulaşılması //int alibabawebadresi
       while(alibabawebadresi_sayac<firma_adi.size()){
           String contacturl=firma_alibaba_contact.get(alibabawebadresi_sayac);
         Document doc12=Jsoup.connect(contacturl)
               .userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0")
               .referrer("http://www.google.com") 
               .timeout(1000*6) //it's in milliseconds, so this means 5 seconds.              
               .get();
         for(Element den:doc12.select("table.company a[href]")){
            firma_websitesi.add(den.attr("href"));
           
           break;
       } 
         alibabawebadresi_sayac++;
       }
           System.out.println("ilk for sonrası firma websitesi size= "+firma_websitesi.size());
         
         //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       while(firmayetkilikisi_sayac<firma_adi.size()){
           String contacturl=firma_alibaba_contact.get(firmayetkilikisi_sayac);
         Document doc123=Jsoup.connect(contacturl)
               .userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0")
               .referrer("http://www.google.com") 
               .timeout(1000*6) //it's in milliseconds, so this means 5 seconds.              
               .get();
         for(Element den1:doc123.select("table.info")){
           firma_yetkilisi.add(den1.select("tr:nth-of-type(1) > .name").text());
           firma_ulke.add(den1.select("tr:nth-of-type(5) > td.value:nth-of-type(2)").text());
           
            if(firma_ulke.get(firmayetkilikisi_sayac).equals("")){
               firma_ulke.set(firmayetkilikisi_sayac, den1.select("tr:nth-of-type(4) > td.value:nth-of-type(2)").text());
               if(firma_ulke.get(firmayetkilikisi_sayac).equals("")){
                    firma_ulke.set(firmayetkilikisi_sayac, den1.select("tr:nth-of-type(3) > td.value:nth-of-type(2)").text());
               
               if(firma_ulke.get(firmayetkilikisi_sayac).equals("")){
                    firma_ulke.set(firmayetkilikisi_sayac, den1.select("tr:nth-of-type(2) > .value").text());
             
           }}}

           Row row=sheet1.createRow(firmayetkilikisi_sayac);
           Row row2=sheet1.createRow(firmayetkilikisi_sayac);
           Row row3=sheet1.createRow(firmayetkilikisi_sayac);
           Row row4=sheet1.createRow(firmayetkilikisi_sayac);
           Row row5=sheet1.createRow(firmayetkilikisi_sayac);
           
           Cell cell =row.createCell(0);
           Cell cell2 =row2.createCell(1);
           Cell cell3 =row3.createCell(2);
           Cell cell4 =row4.createCell(3);
           Cell cell5 =row5.createCell(4);
           
           cell.setCellValue(firma_adi.get(firmayetkilikisi_sayac));
           cell2.setCellValue(firma_alibaba_adresi.get(firmayetkilikisi_sayac));
           cell3.setCellValue(firma_websitesi.get(firmayetkilikisi_sayac));
           cell4.setCellValue(firma_yetkilisi.get(firmayetkilikisi_sayac));
           cell5.setCellValue(firma_ulke.get(firmayetkilikisi_sayac));
           break;
       }
         firmayetkilikisi_sayac++;
       }
           System.out.println("ilk for sonrası firma alibaba yetkili size= "+firma_yetkilisi.size());
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         //----------------------------------------------------------------------------------------------------
         //KONTROL

         
          while(test_outout<firma_adi.size()){
              System.out.println(firma_adi.get(test_outout));
             System.out.println(firma_alibaba_adresi.get(test_outout));
             System.out.println(firma_websitesi.get(test_outout));
             System.out.println(firma_yetkilisi.get(test_outout));
             System.out.println(firma_ulke.get(test_outout));
             test_outout++;
          }
        
          FileOutputStream fileOut=new FileOutputStream("C://Users//alica//Documents//NetBeansProjects//WebScrape//"+kelime+".xls");
           wb.write(fileOut);
     
           
            System.out.println(r+". döngü tamamlandı");
            System.out.println(firma_adi.size()+"= döngü sonrası firma size'ı");
           
    }
    }



*/