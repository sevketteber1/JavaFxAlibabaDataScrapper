
package my.numberaddition;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import javax.swing.JFileChooser;

/**
 *
 * @author alica
 */
public class NewJFrame extends javax.swing.JFrame {
    String filename;
    int marketSize=4;
   
    
    public JTextField getTxtPageNumber() {
        return txtPageNumber;
    }
    public JTextField getTxtProduct() {
        return txtProduct;
    }
    public NewJFrame() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnMarketSize = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtProduct = new javax.swing.JTextField();
        txtPageNumber = new javax.swing.JTextField();
        btnScrape = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnChoose = new javax.swing.JButton();
        txtPath = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        marketSize_1 = new javax.swing.JRadioButton();
        marketSize_2 = new javax.swing.JRadioButton();
        marketSize_3 = new javax.swing.JRadioButton();
        marketSize_4 = new javax.swing.JRadioButton();
        marketSize_5 = new javax.swing.JRadioButton();
        marketSize_6 = new javax.swing.JRadioButton();
        marketSize_7 = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Scrapper"));

        jLabel1.setText("Product:");

        jLabel2.setText("Page Number:");

        txtProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtProductActionPerformed(evt);
            }
        });

        txtPageNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPageNumberActionPerformed(evt);
            }
        });

        btnScrape.setText("Scrape");
        btnScrape.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnScrapeActionPerformed(evt);
            }
        });

        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        btnChoose.setText("Search..");
        btnChoose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChooseActionPerformed(evt);
            }
        });

        txtPath.setText("Choose path of .xls file...");

        jLabel3.setText("Market Size:");

        btnMarketSize.add(marketSize_1);
        marketSize_1.setText("0-1M$");
        marketSize_1.setActionCommand("0-1");
        marketSize_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marketSize_1ActionPerformed(evt);
            }
        });

        btnMarketSize.add(marketSize_2);
        marketSize_2.setText("1-2.5M$");
        marketSize_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marketSize_2ActionPerformed(evt);
            }
        });

        btnMarketSize.add(marketSize_3);
        marketSize_3.setText("2.5-5M$");
        marketSize_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marketSize_3ActionPerformed(evt);
            }
        });

        btnMarketSize.add(marketSize_4);
        marketSize_4.setText("5-10M$");
        marketSize_4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marketSize_4ActionPerformed(evt);
            }
        });

        btnMarketSize.add(marketSize_5);
        marketSize_5.setSelected(true);
        marketSize_5.setText("10-50M$");
        marketSize_5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marketSize_5ActionPerformed(evt);
            }
        });

        btnMarketSize.add(marketSize_6);
        marketSize_6.setText("50-100M$");
        marketSize_6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marketSize_6ActionPerformed(evt);
            }
        });

        btnMarketSize.add(marketSize_7);
        marketSize_7.setText(">100M$");
        marketSize_7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marketSize_7ActionPerformed(evt);
            }
        });

        jButton1.setText("Clean");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnChoose)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnScrape)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(56, 56, 56)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtPageNumber)
                                        .addComponent(txtPath, javax.swing.GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                            .addComponent(marketSize_1)
                                            .addGap(24, 24, 24)
                                            .addComponent(marketSize_2)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(marketSize_3))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                            .addComponent(marketSize_5)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(marketSize_6)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(marketSize_7)))))
                            .addComponent(jLabel3))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(276, 276, 276)
                                .addComponent(jButton1)
                                .addGap(391, 391, 391)
                                .addComponent(btnClear))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(marketSize_4)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtProduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPageNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnChoose)
                    .addComponent(txtPath, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(marketSize_1)
                        .addComponent(marketSize_2)
                        .addComponent(marketSize_3)
                        .addComponent(marketSize_4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(marketSize_5)
                    .addComponent(marketSize_6)
                    .addComponent(marketSize_7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 136, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnScrape)
                    .addComponent(btnClear)
                    .addComponent(jButton1))
                .addGap(36, 36, 36))
        );

        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnExit)
                .addGap(14, 14, 14))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 790, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnExit)
                .addGap(42, 42, 42))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
  public  ArrayList liste_yapici(String arama_kelimesi,int sayfasayisi,int paramiktari){
           String a="https://german.alibaba.com/products/teppich.html?IndexArea=product_en&page=1&viewtype=L&annual_revenue=AR1&param_order=RVN-3";
           String a1="https://german.alibaba.com/products/";
           String a2=arama_kelimesi;
           String a3=".html?IndexArea=product_en&page=";
           int a4=sayfasayisi;
           String a5="&viewtype=L&annual_revenue=AR";
           int a6=paramiktari;
           String a7="&param_order=RVN-3";
           ArrayList<String> liste=new ArrayList(); 
           for(int i=1;i<sayfasayisi+1;i++){
            liste.add(a1+a2+a3+i+a5+a6+a7);
            }
           return liste;
       }
    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
      System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        
        txtPageNumber.setText("");
        txtProduct.setText("");
        
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnScrapeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnScrapeActionPerformed
    
        
        NewJFrame myObject=new NewJFrame();
        Workbook wb=new HSSFWorkbook();
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(new File(filename));
            
        } catch (FileNotFoundException ex) {
            System.out.println("OLMADI1");
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            wb.write(out);
        } catch (IOException ex) {
            System.out.println("OLMADI2");
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            out.close();
        } catch (IOException ex) {
            System.out.println("OLMADI3");
            Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        Sheet sheet1=wb.createSheet("1.sayfa");

        //OLUŞTURUKMUŞ ARRAYLER
        ArrayList<String> firma_adi=new ArrayList<String>();
        ArrayList<String> firma_alibaba_adresi=new ArrayList<String>();
        ArrayList<String> firma_alibaba_contact=new ArrayList<String>();
        ArrayList<String> firma_websitesi=new ArrayList<String>();
        ArrayList<String> firma_yetkilisi=new ArrayList<String>();
        ArrayList<String> firma_ulke=new ArrayList<String>();
        ArrayList<String> mail_adresi=new ArrayList<String>();
        ArrayList<String> contact_adresi=new ArrayList<String>();

        //ARANACAK KELİMENİN GİRİLMESİ

        String aranacak_kelime=txtProduct.getText();

        
        String sayi_alici=getTxtPageNumber().getText();
        int sayfa_sayi=5;
        try{
            sayfa_sayi=Integer.parseInt(sayi_alici);
        }catch(NumberFormatException ex){ // handle your exception
            
        }

        
        //SAYFA GEÇİŞLERİ KONTROLLERİ
        int alibabaadresi_sayac=0;
        int alibabawebadresi_sayac=0;
        int firmayetkilikisi_sayac=0;
        int test_outout=0;
        int website_sayac=0;

        
        ArrayList<String> liste=myObject.liste_yapici(aranacak_kelime, sayfa_sayi, marketSize);

        //FOR DENEME  BAŞLANGIÇ
        for(int b=0;b<liste.size();b++){
            System.out.println(liste.get(b));
        }

        for(int r=0;r<liste.size();r++){
            System.out.println("ilk döngü başladı başladı");
            
            String url=liste.get(r);
            Document document = null;
            try {
                document = Jsoup.connect(url).get();
            } catch (IOException ex) {
                Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
            //Elements links=document.select("div.stitle.util-ellipsis a[href]");
           // Elements links=document.select("div.item-content > .item-grid > .item-extra > .extra-wrap > .stitle > .util-ellipsis");
            Elements links=document.select("div.searchitem-new-theme > .item-content > .item-grid > .item-extra > .extra-wrap > .list-item__minisite-link");

            //Firma adı ve Amazon linkini Arraylere yükleme
            for(Element link:links){
           firma_adi.add(link.text());
           firma_alibaba_adresi.add("https:"+link.attr("href"));
                System.out.println("adres ve firma adı alınıyor");
         }
            for(int i=firma_adi.size()-1; i>0; i--) {
        for(int j=i-1; j>=0; j--) {
            System.out.println("eşitllik kontrolü yapılıyor");
            if(firma_adi.get(i).equals(firma_adi.get(j))) {
                System.out.println("eşit çıktı eleme yapılıyor");
                firma_adi.remove(i);
                firma_alibaba_adresi.remove(i);
                break;
            }
        }
    }
            
            
            System.out.println("EŞİTLEME KONTROLÜ BİTTİ");
            
            

            //----------------------------------------------------------------------------------------------------
            //Firma alibaba contact adresinin Arraye yüklenmesi  //int alibabaadresi_sayac
            while(alibabaadresi_sayac<firma_alibaba_adresi.size()){
                firma_alibaba_contact.add(firma_alibaba_adresi.get(alibabaadresi_sayac)+"/contactinfo.html");
                alibabaadresi_sayac++;
                System.out.println("KONTAKT ADRESİ ALINIYOR");
            }
            

            //----------------------------------------------------------------------------------------------------
            //Contact sayfasında Firmanın web adresine ulaşılması //int alibabawebadresi
            while(alibabawebadresi_sayac<firma_adi.size()){
                String contacturl=firma_alibaba_contact.get(alibabawebadresi_sayac);
                Document doc12 = null;
                try {
                    doc12 = Jsoup.connect(contacturl)
                    .userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0")
                    .referrer("http://www.google.com")
                    .timeout(1000*6) //it's in milliseconds, so this means 5 seconds.
                    .get();
                } catch (IOException ex) {
                    Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("OLMADI5");
                }
                for(Element den:doc12.select("table.company a[href]")){
                    firma_websitesi.add(den.attr("href"));
                    String m_website=firma_websitesi.get(alibabawebadresi_sayac);
            
            if (m_website.charAt(m_website.length()-1)=='/'){
        m_website = m_website.replace(m_website.substring(m_website.length()-1), "");
        firma_websitesi.set(alibabawebadresi_sayac, m_website);
        } 
                    break;
                }
                alibabawebadresi_sayac++;
                System.out.println("FİRMA WEBSİTESİ ALINIYOR");
            }
           
            
            
            
            
while(website_sayac<firma_adi.size()){
    
        try {
                        Document doc = Jsoup.connect(firma_websitesi.get(website_sayac)).get();
                        Pattern p = Pattern.compile("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+");
                         Matcher matcher = p.matcher(doc.outerHtml());
                       if (matcher.find()) {
           mail_adresi.add(matcher.group());
         }
        else{
             
                            String pls;
                            if(contact_alma(firma_websitesi.get(website_sayac)).length()>20){
                               pls= contact_alma(firma_websitesi.get(website_sayac));
                                System.out.println(pls);
                            }
                            else{
                                pls=firma_websitesi.get(website_sayac)+"/"+contact_alma(firma_websitesi.get(website_sayac));
                                 System.out.println(pls);
                            }
                            
                          
                        Document doc1 = Jsoup.connect(pls).get();
                        Pattern p1 = Pattern.compile("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+");
                         Matcher matcher1 = p1.matcher(doc1.outerHtml());
//                        Set<String> emails = new HashSet<String>();
                        
                         
                         //contactinfo.html
                        if (matcher1.find()) {
           mail_adresi.add(matcher1.group());
                            
                            System.out.println("ikinci seferde buldun");
         }
                        else{
                               System.out.println("ikinci seferde bulamadın");
                        
                        
                          mail_adresi.add("empty");
                         
                        }
                        
                         
                            
                
                           
           }
                    } catch (Exception ex) {
                        //java.net.UnknownHostException | java.lang.IllegalArgumentException | java.net.ConnectException | org.jsoup.HttpStatusException | 
                        
                         mail_adresi.add("empty");
                     }   
        website_sayac++;
        
        System.out.println("EMAİL ALINIYOR");
       }
            







            while(firmayetkilikisi_sayac<firma_adi.size()){
                String contacturl=firma_alibaba_contact.get(firmayetkilikisi_sayac);
                Document doc123 = null;
                try {
                    doc123 = Jsoup.connect(contacturl)
                    .userAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0")
                    .referrer("http://www.google.com")
                    .timeout(1000*6) //it's in milliseconds, so this means 5 seconds.
                    .get();
                } catch (IOException ex) {
                    Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("OLMADI6");
                }
                for(Element den1:doc123.select("table.info")){
                    firma_yetkilisi.add(den1.select("tr:nth-of-type(1) > .name").text());
                    firma_ulke.add(den1.select("tr:nth-of-type(5) > td.value:nth-of-type(2)").text());

                    if(firma_ulke.get(firmayetkilikisi_sayac).equals("")){
                        firma_ulke.set(firmayetkilikisi_sayac, den1.select("tr:nth-of-type(4) > td.value:nth-of-type(2)").text());
                        if(firma_ulke.get(firmayetkilikisi_sayac).equals("")){
                            firma_ulke.set(firmayetkilikisi_sayac, den1.select("tr:nth-of-type(3) > td.value:nth-of-type(2)").text());

                            if(firma_ulke.get(firmayetkilikisi_sayac).equals("")){
                                firma_ulke.set(firmayetkilikisi_sayac, den1.select("tr:nth-of-type(2) > .value").text());

                            }}}

                            Row row=sheet1.createRow(firmayetkilikisi_sayac);
                            Row row2=sheet1.createRow(firmayetkilikisi_sayac);
                            Row row3=sheet1.createRow(firmayetkilikisi_sayac);
                            Row row4=sheet1.createRow(firmayetkilikisi_sayac);
                            Row row5=sheet1.createRow(firmayetkilikisi_sayac);
                            Row row6=sheet1.createRow(firmayetkilikisi_sayac);

                            Cell cell =row.createCell(0);
                            Cell cell2 =row2.createCell(1);
                            Cell cell3 =row3.createCell(2);
                            Cell cell4 =row4.createCell(3);
                            Cell cell5 =row5.createCell(4);
                            Cell cell6 =row6.createCell(5);

                            cell.setCellValue(firma_adi.get(firmayetkilikisi_sayac));
                            cell2.setCellValue(firma_alibaba_adresi.get(firmayetkilikisi_sayac));
                            cell3.setCellValue(firma_websitesi.get(firmayetkilikisi_sayac));
                            cell4.setCellValue(firma_yetkilisi.get(firmayetkilikisi_sayac));
                            cell5.setCellValue(firma_ulke.get(firmayetkilikisi_sayac));
                            cell6.setCellValue(mail_adresi.get(firmayetkilikisi_sayac));
                            System.out.println("EXCELE YAZIYOR");
                                   
                            break;
                        }
                        firmayetkilikisi_sayac++;
                    }
                    System.out.println("ilk for sonrası firma alibaba yetkili size= "+firma_yetkilisi.size());
                    

                    while(test_outout<firma_adi.size()){
                        System.out.println(firma_adi.get(test_outout));
                        System.out.println(firma_alibaba_adresi.get(test_outout));
                        System.out.println(firma_websitesi.get(test_outout));
                        System.out.println(firma_yetkilisi.get(test_outout));
                        System.out.println(firma_ulke.get(test_outout));
                        test_outout++;
                    }

                    FileOutputStream fileOut = null;
                    try {
                        fileOut = new FileOutputStream(filename);
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("OLMADI7");
                    }

                    try {
                        wb.write(fileOut);
                    } catch (IOException ex) {
                        Logger.getLogger(NewJFrame.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("OLMADI8");
                    }

                    

                }
                System.out.println("Toplama sonuçlandı");

    }//GEN-LAST:event_btnScrapeActionPerformed

    private void txtPageNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPageNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPageNumberActionPerformed

    private void txtProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtProductActionPerformed

    }//GEN-LAST:event_txtProductActionPerformed

    private void btnChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChooseActionPerformed
        JFileChooser chooser=new JFileChooser();
        chooser.showOpenDialog(null);
        File f=chooser.getSelectedFile();
        filename=f.getAbsolutePath();
        txtPath.setText(filename);
        
    }//GEN-LAST:event_btnChooseActionPerformed

    private void marketSize_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marketSize_1ActionPerformed
        marketSize=1;
    }//GEN-LAST:event_marketSize_1ActionPerformed

    private void marketSize_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marketSize_2ActionPerformed
       marketSize=2;
    }//GEN-LAST:event_marketSize_2ActionPerformed

    private void marketSize_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marketSize_3ActionPerformed
       marketSize=3;
    }//GEN-LAST:event_marketSize_3ActionPerformed

    private void marketSize_4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marketSize_4ActionPerformed
       marketSize=4;
    }//GEN-LAST:event_marketSize_4ActionPerformed

    private void marketSize_5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marketSize_5ActionPerformed
        marketSize=5;
    }//GEN-LAST:event_marketSize_5ActionPerformed

    private void marketSize_6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marketSize_6ActionPerformed
        marketSize=6;
    }//GEN-LAST:event_marketSize_6ActionPerformed

    private void marketSize_7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marketSize_7ActionPerformed
        marketSize=7;
    }//GEN-LAST:event_marketSize_7ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        txtPageNumber.setText("");
        txtPath.setText("");
        txtProduct.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    
     
    
    
    
    
    
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChoose;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnExit;
    private javax.swing.ButtonGroup btnMarketSize;
    private javax.swing.JButton btnScrape;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton marketSize_1;
    private javax.swing.JRadioButton marketSize_2;
    private javax.swing.JRadioButton marketSize_3;
    private javax.swing.JRadioButton marketSize_4;
    private javax.swing.JRadioButton marketSize_5;
    private javax.swing.JRadioButton marketSize_6;
    private javax.swing.JRadioButton marketSize_7;
    private javax.swing.JTextField txtPageNumber;
    private javax.swing.JTextField txtPath;
    private javax.swing.JTextField txtProduct;
    // End of variables declaration//GEN-END:variables

    public static void main(String args[]) throws IOException {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
        
    }

    public static String contact_alma(String webadresi) throws IOException{
           System.out.println("metoda girildi");
         Document doc_con = Jsoup.connect(webadresi).get();
        
         ArrayList<String> links = new ArrayList<String>();
         
        Elements elements = doc_con.select("a[href]");
        for (Element e : elements) {
            links.add(e.attr("href"));
        }
        ArrayList<String> resList = new ArrayList<String>();
        String searchString = "contact";

            for (String curVal : links){
         if (curVal.contains(searchString)){
         resList.add(curVal);
            }
                }
            
           String m_website=resList.get(0);
            
            if (m_website.charAt(0)=='/'){
        m_website = m_website.substring(1);
        resList.set(0, m_website);
                
        } 
            
         System.out.println(resList.get(0));
         
         return resList.get(0);
         
    }

}
